#include <stdio.h>
#include <stdlib.h>
#include "linked_list.h"

LIST createNewList()
{
  LIST temp;
  temp = (LIST)malloc(sizeof(LIST));

  temp->count = 0;
  temp->head = NULL;

  return temp;
}

NODE createNewNode(Element d)
{
  NODE temp;
  temp = malloc(sizeof(NODE));

  temp->data = d;
  temp->next = NULL;
  return temp;
}

void insertNodeIntoList(NODE node, LIST list)
{
  NODE temp;
  temp = malloc(sizeof(NODE));
  list->count++;
  if (list->head==NULL)
  {
    list->head = node;
    // printf("Hi\n");
  }
  else
  {
    temp = list->head;
    while (temp->next != NULL)
    {
      // printf("Hello");
      temp = temp->next;
    }
    temp->next = node;
    node->next = NULL;
  }
}

void printList(LIST l)
{
  NODE temp;
  // temp = malloc(sizeof(NODE));
  if ((l->count) == 0) printf("List is empty \n");
  else
  {
    while (temp->next != NULL)
    {
      temp = temp->next;
      printf("%d - ", temp->data.int_value);
    }
  }
}

void removeFirstNode(LIST list)
{
  NODE temp = list->head;
  list->head = temp->next;
  list->count--;
}

void insertFirstNode(NODE n, LIST list)
{}