#include <stdio.h>
#include <stdlib.h>
#include "element.h"
#include "stack.h"
#include "linked_list.h"
#include <stdbool.h>


Stack *newstack()
{
  LIST l;
}

bool push(Stack *s, Element element)
{
  NODE temp;
  temp->data = element;
  temp->next = s->head;
  s->head = temp;
  if (s->head == NULL)
  {
    return false;
  }
  return true;
  
}